// --- USER PREFERENCES ---
const APP_SETTINGS = {
    keys: {
        mode1: 1, // Key for Standard
        mode2: 2, // Key for Night
        mode3: 9 // Key for Clear
    },
    colors: {
        day: "#0a0817",
        night: "#0a0817"
    }
};

